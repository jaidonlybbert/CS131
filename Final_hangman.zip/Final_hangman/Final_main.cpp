/*
Jaidon Lybbert
12.01.18
Final Project: Hangman
*/

#include<iostream>
#include<iomanip>
#include<vector>
#include<fstream>
using namespace std;


struct gameData {  // container for most of the game data required
    int incorrectGuesses, totalGuesses;
    string hiddenWord;
    vector<char> incorrectLetters;
    vector<char> correctLetters;
    vector<char> wordState;
    const vector<char> alphabet {
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
        'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
    };
};


void load(vector<string>& wordList) {
    // carries word from file to wordList
    string wordRunner;
    // text file of 10,000 words curtesy of MIT
    ifstream wordFile("words.txt");
    // fill vector from file
    for (int i = 0; i < 10000; i++) {
        getline(wordFile, wordRunner);
        wordList.push_back(wordRunner);
    }
    // close file
    wordFile.close();
}


// clears screen
void clear() {
    string clear (75, '\n');
    cout << clear;
}


// displays and updates ascii art
void displayHangmanFigurine(const gameData& currentGame) {
    // initialize ascii art
    vector<string> hangMan {
        "       /-------\\",
        "       |       |",
        "       |       |",
        "               |  {}",
        "               |/ |\\",
        "               |  ||",
        "               |  ||",
        "XXXXXXXXXXXXXXXXXXXXXXXX",
        "XXXXXXXXXXXXXXXXXXXXXXXX",
        "XXXXXXXXXXXXXXXXXXXXXXXX"
    };
    // update the art based on number of incorrect guesses
    if (currentGame.incorrectGuesses >= 1) {
        hangMan[3] = "       0       |  {}";
        hangMan[4] = "       |       |/ |\\";
        hangMan[5] = "       |       |  ||";
    } if (currentGame.incorrectGuesses >= 2) {
        hangMan[4] = "      ||       |/ |\\";
    } if (currentGame.incorrectGuesses >= 3) {
        hangMan[4] = "      |||      |/ |\\";
    } if (currentGame.incorrectGuesses >= 4) {
        hangMan[6] = "        |      |  ||";
    } if (currentGame.incorrectGuesses >= 5) {
        hangMan[4] = "      |||      |/\\|\\";
        hangMan[6] = "      | |      |  ||";
    } if (currentGame.incorrectGuesses == 6) {
        hangMan[3] = "       |       |  {}";
        hangMan[4] = "       x       |  |\\";
        hangMan[5] = "      |||      |\\/||";
        hangMan[6] = "       |       |  ||";
        hangMan[7] = "XXXXXxxxxxXXXXXXXXXXXXXX";
    }
    // print ascii art
    for (int i = 0; i < hangMan.size(); i++) {
        cout << hangMan[i] << endl;
    }
}


// displays the current state of the game
void displayHangman(const gameData& currentGame) {
    // display ascii art
    displayHangmanFigurine(currentGame);
    // display word as it currently stands
    for(int i = 0; i < currentGame.wordState.size(); i++) {
        cout << currentGame.wordState[i] << " ";
    }
    cout << endl << endl;
    // display the incorrect letters
    if (currentGame.incorrectLetters.size() > 0) {
        cout << "Incorrect guesses: " << currentGame.incorrectLetters[0];
        for (int i = 1; i < currentGame.incorrectLetters.size(); i++) {
            cout << ", " << currentGame.incorrectLetters[i];
        }
        cout << endl << endl;
    }
}


// chooses a word at random from a list
void randomWord(gameData& currentGame, const vector<string>& wordList) {
    // only choose words that are longer than 3 letters
    while (currentGame.hiddenWord.length() < 4) {
        // choose random word
        currentGame.hiddenWord = wordList[random() % 10000];
    }
    // construct a vector with underscores representing the unkown letters
    vector<char> temp(currentGame.hiddenWord.length(), '_');
    // copy the vector into the game data
    currentGame.wordState = temp;
}


// hangs one man
bool runGame(const vector<string>& wordList) {
    gameData currentGame;
    int correct;
    string guess;
    vector<char> guessLower;
    bool finish, validWordInput;
    currentGame.hiddenWord = "";
    currentGame.incorrectGuesses = 0;
    currentGame.totalGuesses = 0;
    randomWord(currentGame, wordList);

    // clear the screen
    clear();
    // initial display
    displayHangman(currentGame); // display initial state of the game

    // loop until the player guesses wrong six times
    while(currentGame.incorrectGuesses < 6) {
        // default value: letter not yet proven valid
        correct = -1;
        // clear vector
        guessLower.clear();
        // take user guess as input
        getline(cin, guess);

        // create vector containing lowercase characters of guess
        for (int i = 0; i < guess.length(); i++) {
            guessLower.push_back(static_cast<unsigned char> (tolower(char(guess[i]))));
        }

        // if user guesses a letter
        if (guessLower.size() == 1) {
            // check if letter is in the alphabet
            for (int i = 0; i < currentGame.alphabet.size(); i++) {
                if (guessLower[0] == currentGame.alphabet[i]) {
                    correct = 0;  // letter valid: not yet proven correct
                }
            }
            // if not in alphabet, restart loop
            if (correct == -1) {
                cout << "Invalid input: input must be in the alphabet!\n";
                continue;
            }
            // check if user has already guessed letter
            for (int i = 0; i < currentGame.correctLetters.size(); i++) {
                if (guessLower[0] == currentGame.correctLetters[i]) {
                    correct = 4;  // letter already guessed
                    break;
                }
            }
            for (int i = 0; i < currentGame.incorrectLetters.size(); i ++) {
                if (guessLower[0] == currentGame.incorrectLetters[i]) {
                    correct = 4;  // letter already guessed
                    break;
                }
            }
            // if user has already guessed the letter, restart loop
            if (correct == 4) {
                cout << "You have already guessed that letter!\n";
                continue;
            }

            // check if guess is in the word
            for (int i = 0; i < currentGame.hiddenWord.length(); i++) {
                if (guessLower[0] == currentGame.hiddenWord[i]) {
                    currentGame.wordState[i] = guessLower[0];
                    correct = 1;  // letter proven correct
                }
            }

        // if the user guesses a word
        } else if (guess.length() == currentGame.hiddenWord.length()) {
            correct = 2;
            for (int i = 0; i < currentGame.hiddenWord.length(); i++) {
                if (guessLower[i] != currentGame.hiddenWord[i]) {
                    correct = 3;  // word proven incorrect
                }
            }

        // if the user does not guess a valid word or letter
        } else {
            cout << "Invalid input: input must be a letter or a word of the "
                 << "right length!\n";
            continue;
        }

        // clear display
        clear();
        // update relavant data depending on if the user guessed right
        if (correct == 0) {
            currentGame.incorrectGuesses++;
            currentGame.incorrectLetters.push_back(guessLower[0]);
            cout << "Wrong!\n";
        } else if (correct == 1) {
            currentGame.correctLetters.push_back(guessLower[0]);
            cout << "Right!\n";
        } else if (correct == 2) {
            for (int i = 0; i < currentGame.hiddenWord.length(); i++) {
                currentGame.wordState[i] = guessLower[i];
            }
            cout << "Wow! You guessed it!\n";
        } else if (correct == 3) {
            cout << "WRONG!\n";
            break;
        }
        currentGame.totalGuesses++;

        // display the updated state of the game
        displayHangman(currentGame);

        // check if the word has been filled out completely
        finish = true;  // default value: not yet proven unfinished
        for (int i = 0; i < currentGame.wordState.size(); i++) {
            if (currentGame.wordState[i] == '_') finish = false;
        }

        // end the round if the word has been filled out completely
        if (finish) {
            cout << "Congratulations! You won!\n";
            return true;
        }
    }

    // End the round if the user exceeds 6 guesses
    cout << "Sorry, you lost. Better luck next time!\n"
         << "The word was: " << currentGame.hiddenWord << endl;
    return false;
}


// hangs many men
int main() {
    // seed randomizer
    srand(time(NULL));
    bool playAgain = true;
    bool invalid;
    int wins = 0;
    int losses = 0;
    int plays = 0;
    string playAgainChar;
    vector<string> wordList;
    // constructs wordList from file
    load(wordList);
    // clears screen
    clear();

//-----------------------------------------------------------------------------
// HEADER
//-----------------------------------------------------------------------------
    cout << setfill('-') << setw(81) << "\n"
         << setfill(' ') << setw(51) << "Final Project: Hangman\n"
         << setfill('-') << setw(81) << "\n"
         << R"(
A word will be chosen at random. The characters in the word will be represented
by underscores. Try to guess the characters in the word. If you guess correctly,
all instances of that character will be revealed. you can also try to guess the
word at any time.

To win, guess all the characters in the word, or guess the word.
To lose, guess the characters incorrectly 6 times, or guess the word incorrectly
just once. Good luck.

)";
//-----------------------------------------------------------------------------
// I/O
//-----------------------------------------------------------------------------
    // wait for user input
    cout << "Press Enter to begin: ";
    cin.get();

    // loop until player quits
    while(playAgain == true) {

        // run a round of the game: record results
        if (runGame(wordList) == true) wins++;
        else
            losses++;
        plays++;

        cout << "\nStats:\nWins: " << wins << "\nLosses: " << losses << "\n\n";
        // loop until player makes a choice to either quit or keep playing
        invalid = true;  // default value
        while(invalid == true) {
                cout << "Would you like to play again? (y/n): ";
                getline(cin, playAgainChar);
                if (playAgainChar == "n" || playAgainChar == "N") {
                    playAgain = false;
                    invalid = false;
                }
                else if (playAgainChar == "y" || playAgainChar == "Y") {
                    invalid = false;
                }
                else
                    cout << "Invalid input: please enter 'y' or 'n'.\n";
        }
    }
    // final results
    clear();
    cout << "Thank you for playing!\n";
    return 0;
}
